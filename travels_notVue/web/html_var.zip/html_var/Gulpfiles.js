//引入基础gulp模块
var gulp= require('gulp');