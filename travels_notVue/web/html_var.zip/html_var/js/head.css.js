document.writeln('<link rel="stylesheet" href="/web/css/reset.css" />');
document.writeln('<link rel="stylesheet" href="/web/css/common.css" />');
document.writeln('<link rel="stylesheet" href="//at.alicdn.com/t/font_vbbd4q64fxfde7b9.css">');
